# Módulos de aplicación

## Contenedor de bases de datos

### Tecnologías

### Ficheros relevantes

## Contenedor de aplicación de servidor

### Tecnologías

### Ficheros

### Organización lógica

#### Almacenado de datos de examinado

#### Envío de datos a cliente local

#### Utilidades

##### Hasheado y verificación de contraseña

##### Sistemas ORM

# Bibliografía