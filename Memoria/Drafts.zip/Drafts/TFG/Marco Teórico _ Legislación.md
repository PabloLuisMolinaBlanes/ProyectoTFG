# Legislación

## Protección de datos

## Regulación europea

### Reglamento General de Protección de datos

## Regulación española

### Ley Orgánica de Protección de Datos

## Propiedad intelectual e industrial

### Derechos de autor

#### Ley de Propiedad Intelectual

### Patentes

# Bibliografía