# Pruebas

## Pruebas unitarias

## Pruebas de integración

## Pruebas manuales

# Ciberseguridad

## Seguridad física

## Seguridad en la nube

## Seguridad en el cliente local

# Rendimiento

## Uso de memoria

## Uso de dispositivos externos al Single Board Computer (SBC)

## RTOS

# Documentación

## Comentarios

## Archivos README.md

## Ficheros de pruebas

## Memoria de trabajo

## Manual de usuario

## Ficheros multimedia de demostración

# Bibliografía