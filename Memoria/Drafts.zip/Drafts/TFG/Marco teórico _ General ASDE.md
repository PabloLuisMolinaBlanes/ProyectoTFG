# General ASDE

Originalmente conocidos como *ASDE-Operator* hasta convertirse en la llamada *General ASDE* a finales de 1988, es una empresa dedicada al diseño, fabricación y mantenimiento de Productos Sanitarios, inscrita ante la AEMPS (Agencia Española del Medicamento y el Producto Sanitario); sus productos más conocidos son aquellos relativos al Reconocimiento Médico y Psicotécnico.

Es una empresa con certificado ISO 9001, y desarrolla sus productos conforme a normativas europeas e internacionales; entre los que se incluye la Directiva Europea 93/42/CEE

Su principal producto relativo a realizar reconocimientos psicotécnicos es el denominado Asde Driver Test N-845; basado en el programa predecesor Driver-Test, entonces desarrollado por el equipo compuesto por el profesor de la UPV (Universidad Politécnica de Madrid) Dr. Héctor Monterde i Bort, junto con José Urnaga.

# Bibliografía

https://www.commodorespain.es/driver-test-el-test-psicotecnico-de-conducir-tuvo-su-origen-en-8-bits/
https://www.generalasde.com/webASDE/empresa.php
https://www.generalasde.com/driver-test/