# Técnicas y métricas psicocognitivas

## Medidas

### Tiempo de reacción

### Tiempo de anticipación

### Coordinación mano-ojo

## Técnicas y exámenes psicocognitivos

### Examen de tiempo de anticipación

### Examen de coordinación mano-ojo

# Bibliografía