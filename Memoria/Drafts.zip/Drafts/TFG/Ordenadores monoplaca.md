# Ordenadores monoplaca

## Introducción a los ordenadores monoplaca

## Raspberry Pi 5 16GB

### Características principales

## Otras opciones consideradas

### Otras versiones del Raspberry Pi 5

### Raspberry Pi 4

# Bibliografía