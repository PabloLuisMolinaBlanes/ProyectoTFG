# Ordenadores monoplaca

## Introducción a los ordenadores monoplaca

## Raspberry Pi 5 16GB

### Características principales

## Otras opciones consideradas

Estas son las distintas alternativas al dispositivo elegido que se consideraron a la hora de realizar este proyecto

### Otras versiones del Raspberry Pi 5

Existen varias versiones del Raspberry Pi 5 con menor capacidad de memoria RAM, estas al final no se escogieron para realizar este proyecto, aún siendo las recomendadas por el autor si se busca fabricar este producto de forma masiva por su menor coste, debido a que, al tratarse de un único prototipo no orientado a fabricarse de forma masiva por el momento, he decidido utilizar recursos más potentes al no conocer exáctamente qué recursos harían falta para realizar este proyecto. 

### Raspberry Pi 4 y versiones anteriores

Estas no se escogieron por el mismo motivo que las versiones más baratas del Raspberry Pi 5.

### Mini-PC genérico

Esta opción no se escogió, ya que un Mini-PC genérico es una compilación de hardware propia responsabilidad de su autor, lo cual dificultaría las tareas de aprendizaje inicial; la documentación de Raspberry OS y Raspberry Pi 5 me pareció mucho más completa para un proyecto del cual habían aún muchas incógnitas antes de su comienzo.

# Bibliografía