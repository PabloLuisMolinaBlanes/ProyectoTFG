# Flujo de usuario

## Rol de examinado

### Diagramas

## Rol de examinador

### Diagramas

## Rol de auditor

### Diagramas

## Rol de atacante

### Diagramas

# Bibliografía