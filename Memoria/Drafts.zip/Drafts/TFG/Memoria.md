# Introducción

## FAQ

# Arquitectura y módulos

## Tecnologías

## Módulos

### Firmware

### Web

#### Backend

#### Frontend

### Software de sistemas

### Cloud

#### Backend


# Modelo de datos

# Diagramas de la aplicación

# Manual de usaurio

# README.md

# Conclusiones

# Referencias

# Bibliografía