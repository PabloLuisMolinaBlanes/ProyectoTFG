# Técnicas y fórmulas matemáticas



# Bibliografía