# Microcontroladores

## Introducción general

## ESP-32 DevKit v4

### Características del microcontrolador

#### Funcionalidades del microcontrolador

### Diagrama de pines

## Alternativas consideradas

### Arduino Uno

### Raspberry Pico

# Bibliografía