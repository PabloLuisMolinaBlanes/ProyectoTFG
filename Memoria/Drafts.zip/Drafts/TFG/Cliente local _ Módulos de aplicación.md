# Modulos de aplicación

## Envío de datos al servidor en la nube

## Recepción de datos del servidor en la nube

## Utilidades

### Encriptación y desencriptación de los datos

### Lectura de ficheros informáticos

### Validación de datos introducidos por el usuario

### Utilidades de entrada-salida

### Control y flujo de errores

### Utilidades de comunicación HTTP

# Bibliografía