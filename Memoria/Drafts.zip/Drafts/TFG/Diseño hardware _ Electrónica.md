# Electrónica

Se ha hecho uso de varios dispositivos electrónicos a lo largo del proyecto.

Muchos de estos dispositivos consisten en sensores de determinadas cantidades, por ejemplo; el botón mide si se ha pulsado este o no.

Abajo, se detallan los dispositivos electrónicos a los que se ha hecho uso a lo largo de este Proyecto de Fin de Carrera; junto con una breve explicación de su funcionamiento

## Cableado

### Cables puente

Los cables puente es un tipo de cableado con un conector en cada punta. Estos cables suelen ser utilizados en placas breadboard para conectar dispositivos electrónicos que se encuentren en columnas distintas del breadboard.

### Placa de pruebas

Una Placa de pruebas, o mejor conocido por el anglicismo *breadboard*, es una placa electrónica que se utiliza para realizar circuitos electrónicos sin la necesidad de realizar soldaduras. Es generalmente utilizado en el desarrollo de prototipos, y contrasta con los circuitos soldados o circuitos impresos

## Botón

Un botón electrónico consiste en una resistencia que no deja pasar la corriente cuando se activa un pulsador.

## Potenciometro

Un potenciometro consiste en una resistencia que se puede configurar con un mango. Un potenciómetro puede cambiar su resistencia con respecto al ángulo de rotación de forma linear o logarítmica.

## Cableado USB (Universal Serial Bus)

Se utiliza un cable USB en este proyecto para realizar comunicación entre el dispositivo Raspberry Pi 5 y el dispositivo ESP-32 (se explicarán estos en la siguiente sección. 

Este cable puede realizar funciones útiles en el desarrollo de sistemas empotrados; como cableado serial y de posibilidad de subir firmware a los microcontroladores. Es un cable muy versatil y de gran utilidad en el desarrollo de sistemas embebidos.

El cable específico que se utiliza para el proyecto es un cable USB-C a USB.

# Bibliografía

https://es.wikipedia.org/wiki/Cable_puente
https://es.wikipedia.org/wiki/Placa_de_pruebas
https://www.build-electronic-circuits.com/breadboard/
https://www.digikey.com/en/products/filter/pushbutton-switches/199
https://www.youtube.com/watch?v=Xb-MZMoUtcQ