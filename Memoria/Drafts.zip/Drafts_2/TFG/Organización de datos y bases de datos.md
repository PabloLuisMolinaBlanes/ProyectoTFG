# Organización de datos y bases de datos

## Gestor de bases de datos

### Configuración por defecto

## Modelo de datos

### Tabla ```profile```

#### ```hospital_username```

#### ```hospital_password```

### Tabla ```tests```

#### ```id```

#### ```first_examination```

#### ```second_examination_*```