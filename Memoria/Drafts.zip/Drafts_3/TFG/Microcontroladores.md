# Microcontroladores

## Introducción general

Los microcontroladores son dispositivos informáticos auto-contenidos que se utilizan para proporcionar funcionalidades informáticas variadas sin amplios gastos de electricidad.

En general, suelen ser utilizados cuando se precisa un control prácticamente completo del código que se ejecuta; han encontrado un nicho en el desarrollo de programas que comunican diréctamente con dispositivos electrónicos, o en el desarrollo de software con requisitos críticos de seguridad.

También se benefician de la limitada potencia eléctrica que se necesita para su funcionamiento, permitiendo a estos sistemas ejecutar programas durante años sin estar conectados a una fuente de electricidad constante. 

## ESP-32 DevKit v4

Este microcontrolador es una clase de microcontrolador desarrollado por la compañía EspressIf. [1]

### Características del microcontrolador

Este microcontrolador dispone de las siguientes características relevantes a su funcionamiento. [1] [2]

- Un procesador ESP32-WROOM-32E
- Un chip puente UART-to-USB
- Un puerto USB-to-UART
- Un LED de 5V que se enciende cuando el dispositivo se enciende; es manipulable por los programas escritos a memoria FLASH
- Una serie de conectores, en forma de pines, que actuan como Entrada/Salida (pines ADC (Analog Digital Converter), RX, TX, GPIO, etc)
- Dos botones, uno de descarga, y otro de reinicio.

![esp32-devkitc-v4-functional-overview.png](../_resources/esp32-devkitc-v4-functional-overview.png)

#### Funcionalidades del microcontrolador

Se incluyen múltiples y variadas funciones dentro del microcontrolador. Entre estas se incluye:

- **UEFI**: Es un protocolo de comunicaciones entre dispositivos utilizado de forma interna por el microcontrolador.
- **GPIO**: Es un pin que se utiliza como señal de entrada o de salida.
- **USB**: Es un protocolo de comunicación.

### Diagrama de pines para el proyecto

El dispositivo se conecta a tres dispositivos; utilizándose los siguientes pines:

- Un botón electrónico: Se conecta a los pines GPIO 13, a un pin de 5V, y a un pin de GND.
- Potenciómetro primero: Se conecta a los pines número 27, a un pin 3V3 y a un pin de GND
- Potenciómetro segundo: Se conecta a los pines número 33, a un pin 3V3 y a un pin de GND

![Screenshot from 2026-05-01 14-29-18.png](../_resources/Screenshot%20from%202026-05-01%2014-29-18.png)

## Alternativas consideradas

### Arduino Uno

Se consideró el dispositivo Arduino Uno para realizar el proyecto; al final no se utilizo debido a su precio más elevado, y por su más reducido rendimiento comparado con sus competidores.

### Raspberry Pico

Se consideró el dispositivo Raspberry Pico para realizar el proyecto como microcontrolador; pero se descartó debido a la falta de rendimiento comparado con el ESP-32.

# Bibliografía

[1] ESP32 Series Datasheet Version 5.2 (https://documentation.espressif.com/esp32_datasheet_en.pdf)

[2] ESP32-DevKitC V4 (https://docs.espressif.com/projects/esp-dev-kits/en/latest/esp32/esp32-devkitc/user_guide.html)