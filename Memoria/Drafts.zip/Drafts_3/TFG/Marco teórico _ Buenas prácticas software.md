# Pruebas software

Las pruebas software son fundamentales para asegurarnos que los requisitos se cumplen en todas las versiones del software.

Permite, principalmente, la posibilidad de poder hacer iteraciones comprobando rápidamente que la ejecución del programa sigue siendo como se diseñó en los requisitos.

Las pruebas software deben realizarse de forma lo más automatizada posible, y los más veloces posible. Para ello se enseña que las pirámides deben organizarse en forma de pirámide; siendo la base el tipo idealmente mayoritario de las pruebas realizadas, y conforme nos vamos acercando a la cúspide, un tipo cada vez más minoritario de pruebas.

Principalmente, las pruebas se componen en los siguientes tipos:

## Pruebas unitarias

Es un tipo de pruebas que busca probar una única unidad de funcionalidad dentro del software; forman la base de la pirámide de pruebas y son las que más rápido se deben ejecutar.

Por ejemplo, una prueba unitaria en un programa de calculadora sería probar una función de suma comprobando que, según la función de suma, dos y dos sumarán 4.

## Pruebas de integración

Las pruebas de integración son un tipo de pruebas que analiza varios módulos al mismo tiempo de un conjunto software completo.

Sirven para comprobar que los flujos de información y funcionamiento se secuencian de forma correcta a través de todos los módulos de software probados.

## Pruebas manuales

Las pruebas manuales son un tipo de pruebas que se realizan de forma manual, y que no dependen de procedimientos automatizados como el resto de pruebas anteriormente referidas.

Es el tipo de prueba idealmente menos común, ya que preferiblemente las pruebas se deben realizar de forma automática

# Ciberseguridad

La ciberseguridad refiere a la seguridad de dispositivos informáticos de riesgos relativos a seres humanos; se incluye dentro del campo más general de la seguridad.

La ciberseguridad es fundamental para prevenir las acciones malintencionadas de atacantes informáticos que buscan aprovecharse de deficiencias en los sistemas informáticos para causar daños, perjuicios; o beneficiarse de alguna forma injusta.

La ciberseguridad se abarca desde muchos subcampos distintos. Algunos incluyen:

## Seguridad física

La seguridad física busca prevenir o neutralizar el potencial riesgo que se puede materializar si un ser humano se encuentra en presencia física de un dispositivo informático.

Algunas medidas de seguridad física pueden incluir el realizar una carcasa a un dispositivo informático que solo se puede abrir con una llave específica, mantener el dispositivo informático en una habitación cerrada con llave, entre otras medidas factibles.

## Seguridad en la nube

La seguridad en nube busca proteger a dispositivos informáticos que se encuentran en plataformas de computación en la nube.

Hay varias medidas de seguridad que se pueden tomar aquí, por ejemplo, la de utilizar un cortafuegos para rechazar conexiones sospechosas, no hacer el sistema demasiado complejo para no incrementar la superficie de ataque demasiado, y mantenerse al día con actualizaciones de seguridad.

## Seguridad en el cliente local

La seguridad en los clientes locales busca proteger a dispositivos informáticos que realizan acciones de cliente en dispositivos controlados por los usuarios de una aplicación.

Entre las medidas de seguridad que podemos tomar, se incluye el validar todos los datos que lleguen al cliente, mantenerse al día con actualizaciones de seguridad en todo momento, y comprobar la confianza de todo servidor al que se conecte la aplicación

# Rendimiento

## Uso de memoria

Se ha intentado utilizar la memoria de la forma más controlada posible; esto se hizo haciendo uso de memoria estática, y un uso mínimo de la memoria dinámica.

## Uso de dispositivos externos al Single Board Computer (SBC)

Los datos se miden en dispositivos distintos que los dispositivos donde se procesan estos datos; esto quiere decir que código ejecutándose en dispositivos más complejos que son donde se procesan no van a influenciar los datos recogidos.

## RTOS

Se utilizan los denominados RTOS (Real Time Operating System) que ofrecen garantías deterministas que un proceso se ejecutará no más que un determinado tiempo. Para sistemas de recolección de datos; esto es muy importante.

# Documentación

## Comentarios

## Archivos README.md

## Ficheros de pruebas

## Memoria de trabajo

## Manual de usuario

## Ficheros multimedia de demostración

# Bibliografía