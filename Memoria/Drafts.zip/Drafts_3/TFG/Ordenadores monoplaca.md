# Ordenadores monoplaca

## Introducción a los ordenadores monoplaca

Los ordenadores, usualmente, se almacenan en una carcasa, suelen contener componentes tradicionalmente de gran envergadura, y no es trivialmente transportable.

Para solucionar este problema, se inventaron los ordenadores monoplaca, un ordenador completo que cabe dentro de una placa PCB (Printed Circuit Board)

## Raspberry Pi 5 16GB

El Raspberry Pi 5 es un ordenador monoplaca que viene en múltiples tipos; cada uno distinguido por la cantidad de memoria RAM de la placa.

### Características principales

Las características principales de este dispositivo incluyen:
- Un procesador Broadcom BCM2712.
- Una memoria RAM de 16GB
- Un puerto USB
- Un lector de tarjetas SD

Se pueden incluir otras características no mencionadas aquí

## Otras opciones consideradas

Estas son las distintas alternativas al dispositivo elegido que se consideraron a la hora de realizar este proyecto

### Otras versiones del Raspberry Pi 5

Existen varias versiones del Raspberry Pi 5 con menor capacidad de memoria RAM, estas al final no se escogieron para realizar este proyecto, aún siendo las recomendadas por el autor si se busca fabricar este producto de forma masiva por su menor coste, debido a que, al tratarse de un único prototipo no orientado a fabricarse de forma masiva por el momento, he decidido utilizar recursos más potentes al no conocer exáctamente qué recursos harían falta para realizar este proyecto. 

### Raspberry Pi 4 y versiones anteriores

Estas no se escogieron por el mismo motivo que las versiones más baratas del Raspberry Pi 5.

### Mini-PC genérico

Esta opción no se escogió, ya que un Mini-PC genérico es una compilación de hardware propia responsabilidad de su autor, lo cual dificultaría las tareas de aprendizaje inicial; la documentación de Raspberry OS y Raspberry Pi 5 me pareció mucho más completa para un proyecto del cual habían aún muchas incógnitas antes de su comienzo.

# Bibliografía