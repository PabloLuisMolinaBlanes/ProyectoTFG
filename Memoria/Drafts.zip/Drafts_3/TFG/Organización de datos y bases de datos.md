# Organización de datos y bases de datos

## Gestor de bases de datos

El gestor de bases de datos que se utiliza por defecto es denominado **MySQL**

### Configuración por defecto

La configuración por defecto del gestor es la siguiente.

**Usuario**: root
**Contraseña**: root
No utiliza SSL por defecto

Se genera la siguiente información por defecto en la tabla ```profile```

Una fila con hospital_username "HOSPITAL_MARIA_CRISTINA" y hospital_password un hash bcrypt2 iterado 10 veces de la contraseña "GatitosLindos"

## Modelo de datos

### Tabla ```profile```

#### ```hospital_username```

Aquí se almacena el nombre que utilizará el hospital para acceder a la tabla con sus datos asignados en la tabla ```test```

#### ```hospital_password```

Aquí se almacena un hash de contraseña, junto con la semilla. Este es el formato que se utiliza:

```<hash bcrypt2>;<salt>```

### Tabla ```test```

En esta tabla se incluyen todos los datos relativos a una examinación completa por parte de un examinado en el contexto de una clínica u hospital examinador.

#### ```id```

En este campo se almacenan, de forma encriptada, los datos personales de los examinados.

Se almacenan los datos en el siguiente formato:

```<texto cifrado>;<vector de inicializacion>```

##### Formato de texto descifrado

Consiste en el siguiente formato:

```<Nombre y apellidos del examinado>_<Número de identificación>_<Frase generada al azar con un número indeterminado de caracteres>```

#### ```first_examination```

En este campo se almacenan los resultados relativos a la primera examinación de un examinado.

Se almacenan del siguiente modo:

```<valor de t 1>,<valor de t 2>,<valor de t 3>```

#### ```second_examination_*```

En este campo se almacenan los resultados relativos a la segunda examinación de un examinado.

Se almacenan del siguiente modo:

```<valor de x para coche 1 o 2 en primer fotograma>,<valor de x para coche 1 o 2 en segundo fotograma>,<valor de x para coche 1 o 2 en tercer fotograma>```