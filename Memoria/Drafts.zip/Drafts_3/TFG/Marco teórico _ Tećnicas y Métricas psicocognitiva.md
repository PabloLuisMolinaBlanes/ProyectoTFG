# Técnicas y métricas psicocognitivas

El campo de la psicología cognitiva proporciona a la comunidad científica un entendimiento, desde el punto de vista de la cognición, sobre cómo hacemos uso de nuestros recursos cerebrales en todo tipo de situaciones. Es un campo muy basado en los experimentos.

Este campo dispone de métricas y técnicas que resultan relevantes para asegurar una conducción segura en un contexto de conducción, que son ampliamente utilizadas en exámenes psicotécnicos. Aquí se detallan algunas definiciones importantes:  

## Medidas

### Tiempo de reacción

El tiempo de reacción, según la DGT (Dirección General de Tráfico) mide el tiempo que pasa entre que un conductor percibe un obstáculo o peligro en la carretera, y el tiempo en el que el conductor empieza a reaccionar ante este peligro.

### Velocidad de anticipación

Se define como la capacidad de un sujeto para percibir velocidades y trayectorias, y su capacidad de autocontrol

### Coordinación mano-ojo

La coordinación mano-ojo, para un sujeto, consiste en su capacidad de traducir lo que percibe de forma visual, a movimientos específicos de su mano.

## Técnicas y exámenes psicocognitivos

### Examen de tiempo de anticipación

El examen de tiempo de anticipación se desarrolla primero en el artículo científico de 1962.

En este examen, se presentan dos objetos, un cuadrado blanco, y un tunel; el examinado deberá anticipar, al entrar el cuadrado blanco por un lado del tunel, cuándo saldrá por el otro lado de ese tunel.

Un tiempo demasiado bajo se considera impulsivo, mientras que un tiempo demasiado alto se considera falto en tiempo de reacción.

### Examen de coordinación mano-ojo

El examen de tiempo de anticipación se desarrolla primero en el libro de 1943.

En este examen, se hace uso de un dispositivo el cual muestra dos vehículos, controlados por dos manivelas; cada vehículo se puede accionar a la izquierda o a la derecha.

El objetivo del examinado consiste en mantener los dos vehículos dentro de sus respectivas carreteras, e impedir en la medida de lo posible que cualquiera de los dos vehículos se salga por demasiado tiempo; lo cual indicaría una falla en esta métrica.


# Bibliografía

[1] VELOCIDAD DE ANTICIPACIÓN  - https://www.certificadosmedicosdelphos.es/reconocimientos-medicos/velocidad-de-anticipacion

[2] Manual interactivo Biartic - https://biartic.com/Capacitacion/Anticipacion.php
 