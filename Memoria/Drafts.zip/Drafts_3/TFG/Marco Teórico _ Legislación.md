# Legislación

## Protección de datos

La Protección de los Datos es un campo legal con una larga historia.

En este campo se busca regular todo lo relativo al uso de los datos personales de indivíduos físicos.

Dentro del marco de este proyecto, es muy relevante esta regulación, ya que trabajamos con datos personales de indivíduos físicos directamente, y es importante tomar medidas organizativas y técnicas para prevenir el uso ilícito de estos datos.

En territorio Europeo, todo esto se regula bajo el Reglamento General de Protección de Datos; regulación que se implementa en los territorios nacionales de la Unión Europea.

### Regulación europea

#### Reglamento General de Protección de datos

Reglamento con última versión datada el 4 de Mayo de 2016.

Busca proteger los datos de personas físicas, denominadas como *interesados* en el marco de esta legislación, obligando a los denominados *responsables* a tomar varias medidas por reglamento; se incluyen especificaciones de variada índole, entre las que se incluyen:

- Definiciones de datos personales y tipos de datos personales, junto con sus obligaciones.
- Definición de la figura del responsable, del encargado, delegado, y del interesado en el marco de los datos personales
- Obligación de los responsables de informar a los interesados en sus derechos, en el tratamiento de sus datos, y en otras formas de información.
- Obligación de los responsables a tomar medidas técnicas y organizativas para proteger los datos

Se puede consultar la última versión del reglamento [en el siguiente enlace](https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=CELEX:32016R0679)

Se ha incluido, a modo de ejemplo, un modelo de documento de política de protección de datos a fin de ejemplificación sobre cómo se podría aplicar esta regulación a este proyecto.

### Regulación española

#### Ley Orgánica de Protección de Datos

Implementa el marco legal instaurado con el Reglamento General de Protección de Datos a nivel Europeo en el marco legislativo Español.

Se puede consultar su última versión en la página web del BOE (Boletín Oficial Español), [en este documento digital](https://www.boe.es/buscar/act.php?id=BOE-A-2018-16673)

## Propiedad intelectual e industrial

La Propiedad Intelectual e industrial son campos legales que tienen en común proteger las creaciones originales; ya sean de un creador de una obra intelectual, o ya sean de un inventor.

Estos campos legales han tomado derivas muy distintas, y habitualmente se estudian por separado; pero para los fines de este trabajo, los vamos a tratar dentro de la misma sección.

Este trabajo, especialmente al ser una recreación moderna de un tipo de productos ya existentes, ha de ser únicamente cuidadoso en respetar los derechos de autor y patente de las obras originales en las que se basa el proyecto; no debe utilizar código ni implementaciones de sus precursores sin autorización explícita de los titulares de los derechos de explotación y morales.

Vamos a detallar aquí un poco más este marco legal específico:

### Derechos de autor

Los derechos de autor se regulan de forma muy diversa; de forma muy general, podemos decir que consisten, dentro del contexto de una obra intelectual original, los derechos exclusivos que un autor posee sobre ella por virtud de su creación; estos derechos pueden o no ser transferibles a otros titulares.

#### Ley de Propiedad Intelectual

Dentro del marco regulativo de España, esta es la ley que regula el derecho de Propiedad Intelectual.

Divide los derechos que posee un autor en **derechos morales** y **derechos de explotación**, no excluyéndose otros derechos que el autor pueda poseer sobre su obra.

Se puede consultar el texto legal actual [en el siguiente enlace](https://www.boe.es/buscar/act.php?id=BOE-A-1996-8930)

### Patentes

Las patentes son instituciones legales que protegen ciertos derechos exclusivos que posee un inventor sobre su propia invención.

Este campo es muy amplio, pero a modo genérico podemos decir que un inventor puede patentar una invención original con el fin de obtener una serie de derechos exclusivos y limitados en el tiempo sobre esta invención, incluyendo su fabricación o distribución.

## Legislación referida a Dispositivos Médicos

# Bibliografía

Documento oficial del RGPD - https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=CELEX:32016R0679

Ley Orgánica de Protección de Datos - https://www.boe.es/buscar/act.php?id=BOE-A-2018-16673

LAW-FAQ o CATECISMO JURÍDICO PARA INFORMÁTICOS 2. PROTECCIÓN DE DATOS. Por José Luis Pérez de la Cruz Molina, licenciados bajo el CC-BY.

LAW-FAQ o CATECISMO JURÍDICO PARA INFORMÁTICOS 3. PROPIEDAD INTELECTUAL E
INDUSTRIAL. Por José Luis Pérez de la Cruz Molina, licenciados bajo licencia CC-BY.