# Técnicas y fórmulas matemáticas

## Media aritmética

## Detección de colisiones

La detección de colisiones, al tratarse de una operación de una única dimensión, se realiza por medio de la siguiente operación matemática:

Siendo $x_c$ la posición en x del coche, $s_c$ la anchura en x del coche, $x_w$ la posición en x de la pared y $s_w$ la anchura en x de la pared, se calcula si se ha producido una colisión de la siguiente forma

$f(x) =$ $\begin{cases}0 & (x_c < x_w) \lor (x_c > x_w+(s_w-s_c))\\ 1 & (x_c \geq x_w) \lor (x_c \leq x_w+(s_w-s_c)) \end{cases}$

De ser el resultado 0, afirmamos que el vehículo se encuentra dentro de la pared; de ser el resultado 1, afirmamos que el vehículo se encuentra fuera de la pared.

## Criptografía

La criptografía es un campo de las matemáticas aplicadas. Busca asegurar una comunicación segura contra adversarios.

## Funciones hash

Son funciones que generan una entrada de tamaño variable, y devuelven una salida de tamaño fijo. Para que estas funciones sean seguras, debe ser resistente ante colisiones (es decir, dos valores que se resuelvan a la misma salida), y para la misma entrada, siempre se debe computar la misma salida. 

### Encriptación en bloque

Consiste esta en una modalidad de encriptación que devuelve un texto cifrado cifrándolo a lo largo de varios bloques. El texto sin descifrar entonces se dividiría en varios bloques, cada uno del tamaño de la clave, y se cifraría progresivamente repitiendo la misma clave para todos los bloques.

Para descifrar, sería cuestión de dividir el texto cifrado en bloques, y descifrar progresivamente haciendo la operación inversa con la clave.

Cuando la clave no se repite, y es de la misma longitud que el texto cifrado, estaríamos haciendo uso de una libreta de un solo uso.

#### Encriptación AES

El cifrado AES consiste en una variación del cifrado por bloques Rijndael, originalmente diseñado por Joan Daemen y Vincent Rijmen.

Se basa en una red de sustitución-permutación; donde se definen dos tipos de bloques, denominados S-boxes y P-boxes, que realizan varias iteraciones alternantes sobre una clave y un texto a cifrar; para devolver un texto cifrado.

##### Modalidad ECB

La modalidad ECB consiste en utilizar la clave únicamente para realizar la encriptación. Es un modelo poco recomendado ya que un atacante puede obtener patrones a partir del texto cifrado.

![ECB_encryption.svg.png](../_resources/ECB_encryption.svg.png)

#### Modalidad CBC

La modalidad CBC añade el concepto de un vector de inicialización, que se genera de forma aleatoria, y que se utiliza para prevenir que un texto cifrado, para la misma entrada, sea siempre el mismo. Esto impide que un atacante pueda obtener información utilizando patrones del texto cifrado.

![CBC_encryption.svg.png](../_resources/CBC_encryption.svg.png)

# Bibliografía

https://en.wikipedia.org/wiki/Cryptography#Cryptographic_hash_functions

https://en.wikipedia.org/wiki/Substitution%E2%80%93permutation_network

https://en.wikipedia.org/wiki/Block_cipher_mode_of_operation