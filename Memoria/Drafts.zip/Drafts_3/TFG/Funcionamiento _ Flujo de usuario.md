# Flujo de usuario

## Rol de examinado

### Diagramas

#### Flujo de realización del primer examen

#### Flujo de realización del segundo examen

## Rol de examinador

### Diagramas

#### Flujo de subida de datos al examen

## Rol de auditor

### Diagramas

#### Flujo de realización de auditoría

## Rol de atacante

### Diagramas

#### Flujo de intento de ataque MitM

#### Flujo de intento de localización de servidor

#### Flujo de obtención de datos de base de datos

# Bibliografía