# Manual de usuario

En este manual de usuario se busca introducir a todos los tipos de usuario, de forma sencilla, y paso por paso, a un uso adecuado de esta suite de software.

## Para el usuario

### ¿Cómo realizar una examinación?

Para las examinaciones, lo más importante es la pantalla, y los botones o manivelas que hayas de utilizar. Cuando actuas sobre los botones o las manivelas, esto causará efectos en la pantalla, que están hechos para que se puedan visualizar fácilmente.

Tu doctor te hará dos tipos de examinación, vamos a entrar un poco más en detalle en los exámenes que habrás de realizar:

#### Primera examinación

La primera examinación busca medir tu tiempo de anticipación. Vamos a mostrar una fotografía de lo que probablemente vas a ver en la pantalla:

[Placeholder aquí]

Tu objetivo en esta examinación consiste en, cuando el coche, representado por el cuadradito blanco, entre en el tunel, representado por el cuadrado grande por la izquierda; debes intentar anticiparte, y pulsar el botón cuando creas que el coche va a salir por la derecha.

El examen se repite tres veces; y en cada una, deberás hacer lo mismo; el programa se cerrará cuando haya concluido el examen.

#### Segunda examinación

La segunda examinación busca medir tu coordinación mano-ojo, utilizarás las dos manivelas que podrás ver en la pantalla. Aquí mostramos una foto de lo que verás durante el examen:

[Placeholder aquí]

Tu objetivo en esta examinación consiste en mantener los coches, representados por los cuadraditos blancos, dentro de cada carretera; hay una carretera por cada coche. Esta carretera tiene curvas, y tu objetivo será mantener los dos cuadraditos en todo momento dentro de su carretera. El cuadradito de la izquierda tendrá que circular en la carretera de la izquierda en todo momento, y el cuadradito de la derecha tendrá que circular en la carretera de la derecha en todo momento.

Cuando haya terminado el examen, el programa se cerrará.

### ¿Cómo subo una examinación?

Tu doctor abrirá un programa donde tendrás que introducir los siguientes datos:

- Un nombre y apellidos personales.
- Un tipo de documento de identificación (puede ser un documento DNI o NIE)
- Un número de documento de identificación

Tu doctor te proporcionará un formulario físico, aquí se incluyen los derechos que tienes relativos a tus datos personales, y qué se va a hacer con ellos; leelo con atención, plantea todas las dudas que tengas, y si consientes al tratamiento indicado, firma el documento.

Después, se mostrará en la pantalla si quieres confirmar que todos tus datos se vayan a subir a la nube. Lee bien y comprueba que los datos en pantalla es lo que de verdad quieres subir; cuando hayas concluido esto, tus datos ya estarán subidos.

## Para el doctor

### ¿Qué examinaciones se utilizan?

#### Primera examinación

La primera examinación que se realiza se trata del test del tunel, originalmente basado del estudio por MARUYAMA, KINYA y KITAMURA, SEIRO en 1966

#### Segunda examinación

La segunda examinación que se realiza se trata del test del laberinto, originalmente derivado del polireactografo explicado en el libro por Bonnardel, Raymond en 1943



### ¿Cómo cargo los programas de examinación?

Los programas de examinación han de accederse a través de la carpeta ```bin/``` que se pueden encontrar en la carpeta ```SystemSoftware/Integrated```. Hay dos programas, estos son:

```first_examination```: Este programa es la primera examinación

```second_examination```: Este programa es la segunda examinación

```gui```: Una interfaz sencilla que permite abrir los dos programas de examinación sin tener que acordarte de dónde está cada programa.

Has de abrir los programas para cada examen, y dar instrucciones al examinado sobre cómo realizar cada examen; preferiblemente deberías realizar una demostración, para luego que puedan hacer el examen real.


### Interpretación de los datos

Los datos se cargan en dos archivos de texto; estos se denominan:

```first_examination.txt```: Mide el tiempo de pulsación; no pasa nada si no corresponde a los segundos exactos que el examinado tardó en pulsar. El valor óptimo debería ser alrededor de 0.90.

```second_examination.txt```: Mide la posición de los dos coches a lo largo del examen.

### ¿Cómo subo los datos del usuario?

Debes copiar en el directorio ```Web/Integrated/build``` los archivos ```first_examination.txt``` y ```second_examination.txt```. Tras hacer esto, deberás correr el siguiente comando en la terminal: ```npm run dev```.

Se mostrará una pantalla donde puedes escoger entre varias opciones, la que interesa para subir los datos será la opción número 1.

Antes de pulsar la opción, presenta al usuario con un formulario de política de protección de datos. **Asegurate que el usuario firma este formulario antes de subir la información**.

A partir de aquí, después de que el usuario introduzca sus datos, antes de subirlo deberías dar tiempo al usuario para que lea y comprenda todo bien y que todo sea correcto.

### ¿Cómo puedo obtener todos los datos de cada usuario?

Deberás abrír el directorio ```Web/Integrated/build```, y correr el siguiente comando en terminal ```npm run dev```.

Si no habías ejecutado el programa nunca jamás hasta ahora, debes comprobar primero si existe un archivo denominado ```encryptionparameters.txt```, si ese archivo existiese sin haber nunca abierto este programa, **debe descartarse el dispositivo immediatamente y pedir la instalación de un dispositivo nuevo, con credenciales actualizadas**.

Se mostrará una pantalla donde puedes escoger entre varias opciones, la que interesa para subir los datos será la opción número 2. Se generará automáticamente un archivo llamado ```html_results.html```; donde se incluirán los datos de los examinados en forma de tabla.


## Para el auditor

### ¿Cómo puedo realizar auditoría de los datos?

Podrás obtener acceso a partir de las credenciales de cada hospital a los datos que se contienen en ellos; a partir de ahí, podrás obtener una tabla con todas las examinaciones realizadas.

Todos los datos escritos relativos a las pruebas se deben verificar con la misma versión del programa con la que se han generado, de no ser así, se puede llegar a conclusiones erróneas.

### ¿Qué datos tengo disponibles para auditar?

Tendrás datos de los examinados respecto a sus acciones en los exámenes de tiempo de anticipación y de coordinación mano-ojo.

Para el primer examen, se mide el tiempo de pulsación; no pasa nada si no corresponde a los segundos exactos que el examinado tardó en pulsar. El valor óptimo debería ser alrededor de 0.90.

Para el segundo examen, se mide la posición de los dos coches a lo largo del examen.

### He encontrado un usuario que no debería haber aprobado por motivos médicos, ¿qué puedo hacer?

Puedes, por orden judicial, pedir que se desencripten los datos asociados al usuario, y que se verifique si esta persona se le ha autorizado el tener el carnet de conducir, o no.

Por defecto todos los datos personales de usuarios se encuentran encriptados, por lo que no podrás acceder a ellos hasta que una orden judicial exija su desencriptación.